# Example Package

This is a simple example package. You can use

[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)

to write your content.






# 生成wheel 库

python setup.py sdist bdist_wheel 

#上面会生成一些文件  自己看一看 dist下的 可以安装

# 上传

tmine upload dist/*　

#　或者 

python setup.py sdist bdist_wheel upload



