from setuptools import setup, find_packages

setup(

    name='Flask_Look_Mysql', #　名称

    version='1.0.2', #　版本

    keywords='flask look mysql html', # 关键词

    description='a look mysql html', # 描述

    license='MIT License', #　啥子认证哦　直接ｃｏｐｙ

    url='https://github.com/libaibuaidufu/Flask-Look-Mysql', # 地址 可以指向自己的 开源库

    author='libaibuaidufu', # 作者

    author_email='dfk@gmail.com', # 邮箱

    packages=find_packages(), # 不知道

    include_package_data=True, # 不知道

    platforms='any', # 平台

    install_requires=["numpy"], # 依赖库

)